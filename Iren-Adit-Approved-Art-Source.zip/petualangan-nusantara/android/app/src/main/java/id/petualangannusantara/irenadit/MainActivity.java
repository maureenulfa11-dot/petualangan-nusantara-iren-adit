package id.petualangannusantara.irenadit;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
