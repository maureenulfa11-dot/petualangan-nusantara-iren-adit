// Komposisi baru. Nada dinyatakan sebagai derajat tangga nada, dengan null sebagai jeda.
const R = null;
const pelog = [0, 133, 390, 680, 814];
const pentatonic = [0, 198, 386, 702, 905];
const mode = [0, 205, 495, 702, 995];

const line = (instrument, notes, octave = 0, volume = 1) => ({ instrument, notes, octave, volume });

export const MUSIC = {
  aceh: { title: 'Angin di Serambi', step: .178, root: 62, tuning: [0, 155, 390, 500, 705, 865, 1000], lines: [
    line('reed', [0,R,1,2,4,R,2,1,0,R,2,3,4,5,R,4,2,1,R,0,2,R,3,4,5,4,3,2,1,R,0,R]),
    line('frame', [0,R,R,0,R,3,R,0,0,R,3,R,0,R,3,R], -2, .8),
    line('gong', [0,R,R,R,R,R,R,R,4,R,R,R,R,R,R,R], -2, .57),
  ] },
  toba: { title: 'Riak di Kaki Kaldera', step: .185, root: 59, tuning: [0, 204, 372, 706, 890], lines: [
    line('flute', [2,R,3,4,3,2,R,1,0,2,R,1,3,R,4,R,5,4,3,R,4,2,1,R,3,R,2,1,0,R,1,0]),
    line('plucked', [0,R,3,2,R,0,1,R], -1, .80),
    line('drum', [0,R,2,R,1,3,R,2,0,R,3,2,R,1,3,R], -2, .70),
  ] },
  minang: { title: 'Gema Gonjong', step: .144, root: 65, tuning: [0, 182, 405, 683, 911], lines: [
    line('kettle', [0,2,R,3,4,R,3,2,1,3,2,R,1,0,R,2,4,R,5,4,3,4,2,R,1,2,3,1,2,R,0,R]),
    line('flute', [R,R,R,2,R,3,R,R,R,R,R,4,R,2,R,R], 0, .56),
    line('frame', [0,R,2,R,0,R,R,3], -2, .65),
  ] },
  jawa: { title: 'Gema Teras Candi', step: .208, root: 61, tuning: pelog, lines: [
    line('metal', [0,R,R,1,2,R,R,4,3,R,R,2,1,R,R,0,2,R,R,3,4,R,R,3,1,R,R,2,1,R,R,0], -1),
    line('kettle', [R,4,R,3,R,2,R,4,R,5,R,3,R,2,R,1], 0, .57),
    line('gong', [0,R,R,R,R,R,R,R,2,R,R,R,R,R,R,R,3,R,R,R,R,R,R,R,0,R,R,R,R,R,R,R], -3, .75),
    line('drum', [R,R,0,R,2,R,3,R], -2, .53),
  ] },
  kalimantan: { title: 'Jalinan Arus Kayu', step: .147, root: 58, tuning: pentatonic, lines: [
    line('plucked', [0,1,3,4,R,3,2,1,0,2,3,R,2,4,3,R,2,3,4,5,R,4,3,1,2,R,3,1,0,1,0,R]),
    line('plucked', [0,R,0,R,3,R,0,R], -1, .62),
    line('wood', [R,R,2,R,R,R,3,R], -1, .31),
  ] },
  sulawesi: { title: 'Dentang Lembah Pagi', step: .166, root: 63, tuning: pentatonic, lines: [
    line('wood', [2,4,3,R,4,5,4,2,1,2,R,4,3,2,1,R,0,2,4,3,5,R,4,3,2,1,3,2,1,R,0,R]),
    line('wood', [0,R,R,3,0,R,2,R,1,R,R,4,1,R,3,R], -1, .74),
    line('wood', [R,2,R,R,R,3,R,2], 1, .30),
    line('drum', [0,R,R,R,0,R,R,2], -2, .35),
  ] },
  papua: { title: 'Langkah di Punggung Awan', step: .191, root: 60, tuning: mode, lines: [
    line('tifa', [0,R,2,0,R,3,0,R,2,R,0,3,0,R,2,R], -2, 1.25),
    line('flute', [R,R,0,R,2,R,3,R,4,R,2,R,1,R,2,R,3,R,4,5,R,4,3,R,2,R,3,R,1,R,0,R], 0, .75),
    line('wood', [R,2,R,R,R,1,R,3], -1, .42),
  ] },
  bali: { title: 'Senja Saling Menjawab', step: .137, root: 61, tuning: pelog, lines: [
    line('pulse', [0,R,1,R,R,0,R,2], -2, .83),
    line('pulse', [R,2,R,1,3,R,1,R], -1, .66),
    line('metal', [R,R,0,R,3,R,4,R,3,R,2,R,1,R,2,R,4,R,3,R,4,R,5,R,4,R,2,R,1,R,0,R], 0, .72),
    line('gong', [0,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,3,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R], -3, .81),
  ] },
  senja: { title: 'Keping Terakhir', step: .192, root: 60, tuning: pentatonic, lines: [
    line('plucked', [0,1,2,R,3,R,4,3,2,3,4,R,5,4,2,R,3,4,5,R,6,5,4,R,2,4,3,2,1,R,0,R]),
    line('flute', [R,R,2,R,R,R,4,R,R,R,3,R,R,R,2,R], 0, .58),
    line('gong', [0,R,R,R,R,R,R,R,4,R,R,R,R,R,R,R], -2, .45),
  ] },
};

// [rasio frekuensi, kekuatan, panjang bunyi], semua dimainkan oleh sintesis lokal.
export const TIMBRES = {
  reed: [[1,.105,.34], [2,.033,.30], [3,.048,.26], [5,.012,.19]],
  flute: [[1,.130,.44], [2,.028,.31], [3,.010,.16]],
  plucked: [[1,.122,.37], [2.006,.036,.19], [3.02,.019,.11], [5.04,.011,.055]],
  wood: [[1,.133,.31], [3.98,.034,.12], [9.16,.012,.064]],
  kettle: [[1,.094,.42], [2.73,.046,.24], [4.06,.014,.095]],
  metal: [[1,.109,.66], [2.36,.028,.36], [4.12,.017,.20]],
  gong: [[1,.133,1.50], [1.48,.042,1.22], [2.08,.026,.74], [3.35,.012,.37]],
  drum: [[1,.118,.18], [1.56,.043,.11], [3.1,.017,.051]],
  frame: [[1,.103,.16], [2.17,.038,.068], [5.21,.020,.051]],
  tifa: [[1,.144,.24], [1.63,.068,.139], [3.22,.020,.053]],
  pulse: [[1,.105,.10], [2.17,.029,.067], [5.76,.018,.047]],
};
