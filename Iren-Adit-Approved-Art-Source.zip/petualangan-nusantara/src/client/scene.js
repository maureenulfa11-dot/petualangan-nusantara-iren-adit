import Phaser from 'phaser';
import {
  CHAPTERS, CAST, WIDTH, FLOOR, PIT, EXIT, CRANK, RAFT_HALF, RAFT_PAD,
  BRIDGE_SWITCHES, BRIDGE_REACH, CLUE_HIGH, CLUE_LOW, PATTERN, CLIMB, PADS, TIMERS,
  stageOf, stageQuestionStart, platformsFor, hasPit, within,
} from '../shared/chapters.js';
import { drawAvatar, AVATAR_WIDTH, AVATAR_HEIGHT, AVATAR_PIXELS } from './avatar.js';
import { hasSpriteLook } from './avatar-sprites.js';

const VIEW_W = 960;
const VIEW_H = 480;
const HERO_SCALE = .88;
const PALETTE = {
  cream: 0xffe6ab, gold: 0xf1be66, deep: 0x243d37, brown: 0x704f42, timber: 0xa77854,
  teal: 0x3f8069, fern: 0x8eb36e, light: 0xe7bd83, stone: 0x6e8077,
};
const COLORS = [0xffe9b2, 0xc5f0e0];
const PAINTED = ['aceh', 'toba', 'minang', 'jawa', 'kalimantan', 'sulawesi', 'papua', 'karang', 'bali'];
const text = { fontFamily: 'Plus Jakarta Sans Variable, sans-serif', color: '#fff4d4', fontSize: '13px', fontStyle: 'bold', stroke: '#25433b', strokeThickness: 4 };

class AdventureScene extends Phaser.Scene {
  constructor(read) {
    super('adventure');
    this.read = read;
    this.artKeys = [...new Set(CHAPTERS.flatMap(ch => ch.stages.map(stage => stage.landscape || stage.theme)))];
  }

  preload() {
    PAINTED.forEach(key => this.load.image(key + '-painted', '/art/' + key + '-painted.webp'));
    for (const key of this.artKeys) {
      this.load.svg(key + '-far', '/art/' + key + '-far.svg');
      this.load.svg(key + '-near', '/art/' + key + '-near.svg');
    }
  }

  create() {
    this.cameras.main.setBounds(0, 0, WIDTH, VIEW_H);
    this.cameras.main.setBackgroundColor('#216155');
    this.stageObjects = this.add.container();
    this.clouds = this.add.graphics().setDepth(2);
    this.water = this.add.graphics().setDepth(3);
    this.bridgeDeck = PIT.map((x, i) => this.bridgeHalf(x, i === 0 ? 1 : -1));
    this.dynamic = this.add.graphics().setDepth(8);
    this.foreground = this.add.graphics().setDepth(16);
    this.hero = [0, 1].map(i => {
      const canvas = this.textures.createCanvas('hiker-' + i, AVATAR_WIDTH * AVATAR_PIXELS, AVATAR_HEIGHT * AVATAR_PIXELS);
      return {
        canvas,
        image: this.add.image(0, 0, canvas.key).setScale(HERO_SCALE / AVATAR_PIXELS).setOrigin(.5, .905).setDepth(12),
        name: this.add.text(0, 0, '', { ...text, fontSize: '14px' }).setOrigin(.5).setDepth(14),
      };
    });
    this.targetIcon = this.add.text(0, 0, '', { ...text, fontSize: '19px' }).setOrigin(.5).setDepth(10);
    this.bridgeSigns = BRIDGE_SWITCHES.map(x => this.add.text(x, FLOOR - 89, '', {
      ...text, fontSize: '16px', padding: { x: 9, y: 5 }, backgroundColor: '#173d39', strokeThickness: 0,
    }).setOrigin(.5).setDepth(11).setVisible(false));
    this.lastArt = -100;
  }

  stageArt(world) {
    this.stageObjects.removeAll(true);
    const stage = stageOf(world);
    const backdrop = stage.landscape || stage.theme;
    const painted = (PAINTED.includes(backdrop) ? backdrop : stage.theme) + '-painted';
    const layer = key => this.add.image(0, 0, key).setOrigin(0);
    this.backdrop = this.textures.exists(painted) ? layer(painted).setScale(FLOOR / 335) : layer(backdrop + '-far');
    this.stageObjects.add(this.backdrop);
    this.nearBackdrop = !this.textures.exists(painted) ? layer(backdrop + '-near') : null;
    if (this.nearBackdrop) this.stageObjects.add(this.nearBackdrop);
    const floor = this.add.graphics();
    this.stageObjects.add(floor);
    const banks = hasPit(stage) ? [[0, PIT[0]], [PIT[1], WIDTH]] : [[0, WIDTH]];
    if (hasPit(stage)) {
      floor.fillStyle(stage.mode === 'cable' ? 0x608b9c : 0x4da7a9, 1).fillRect(PIT[0], FLOOR + 29, PIT[1] - PIT[0], 91);
      floor.fillStyle(0x4e949b, 1).fillRect(PIT[0], FLOOR + 61, PIT[1] - PIT[0], 63);
      floor.lineStyle(2, 0xa9e5cc, .64);
      for (let i = 0; i < 14; i++) floor.lineBetween(512 + (i * 63 % 261), 430 + (i * 17 % 43), 533 + (i * 63 % 261), 430 + (i * 17 % 43));
    }
    for (const [left, right] of banks) this.ground(floor, left, right, stage);
    for (const [left, right, y] of platformsFor(stage)) {
      floor.fillStyle(0x586961, 1).fillRoundedRect(left, y, right - left, 24, 6);
      floor.fillStyle(0x8ba97b, 1).fillRoundedRect(left - 2, y - 2, right - left + 4, 8, 4);
      floor.lineStyle(2, 0xb8c580, .85).lineBetween(left + 4, y, right - 4, y);
      floor.lineStyle(2, 0x405a55, .65).lineBetween(left + 11, y + 14, right - 8, y + 14);
    }
    this.cameraX = 112;
    this.cameraY = 270;
    this.bridgeLift = 0;
    this.bridgeDeck.forEach(deck => deck.setVisible(stage.mode === 'bridge'));
    this.bridgeSigns.forEach(sign => sign.setVisible(stage.mode === 'bridge'));
    this.raftX = undefined;
    this.hero.forEach((h, i) => h.image.setPosition(110 + i * 50, FLOOR));
  }

  ground(g, left, right, stage) {
    const width = right - left;
    g.fillStyle(0x69544a, 1).fillRect(left, FLOOR, width, VIEW_H - FLOOR);
    g.fillStyle(0x7c6052, 1).fillRect(left, FLOOR, width, 31);
    g.fillStyle(0x97745a, 1).fillRect(left, FLOOR, width, 14);
    g.fillStyle(0x517957, 1).fillRect(left, FLOOR - 4, width, 10);
    g.fillStyle(0xa6be76, 1).fillRect(left, FLOOR - 4, width, 3);
    for (let x = left + 5; x < right - 5; x += 13) {
      const n = (x * 29) % 17;
      g.fillStyle(x % 5 ? 0x63865a : 0xaac275, 1).fillTriangle(x - 3, FLOOR, x + (x % 5), FLOOR - 7 - n / 2, x + 6, FLOOR);
      if (x % 3 === 0) {
        g.fillStyle(n % 2 ? 0x8a6a58 : 0x584b45, .78).fillEllipse(x, FLOOR + 14 + (x * 31) % 72, 4 + n, 3 + n / 3);
      }
    }
    for (let x = left + 30; x < right - 30; x += 124) {
      const stem = x + (x * 9 % 26);
      this.leaves(g, stem, FLOOR + 4, x % 5 ? 0x396c4b : 0x5d894a, x % 7);
      this.leaves(g, stem + 9, FLOOR + 1, x % 5 ? 0x63934d : 0x93aa51, (x + 3) % 7);
      const petal = stage.theme === 'bali' ? 0xffa1b4 : stage.theme === 'papua' ? 0xda9ddb : 0xffd17f;
      if (x % 3) for (let i = 0; i < 3; i++) {
        const flowerX = stem + 3 + i * 6;
        const flowerY = FLOOR - 13 - i * 3;
        g.lineStyle(1.6, 0x5c8a47, 1).lineBetween(stem + 8, FLOOR, flowerX, flowerY);
        g.fillStyle(petal, 1).fillCircle(flowerX - 2, flowerY, 2.3).fillCircle(flowerX + 2, flowerY, 2.3).fillCircle(flowerX, flowerY - 2, 2.3);
        g.fillStyle(0xffe6a0, 1).fillCircle(flowerX, flowerY, 1.3);
      }
    }
  }

  leaves(g, x, y, color, sway) {
    g.fillStyle(color, 1);
    for (let i = -2; i <= 2; i++) {
      const dx = i * (7 + sway / 3);
      const height = 16 - Math.abs(i) * 3;
      g.fillTriangle(x, y, x + dx, y - height, x + dx + 6, y - height / 2);
    }
  }

  bridgeHalf(x, direction) {
    const g = this.add.graphics({ x, y: FLOOR }).setDepth(6).setScale(direction, 1).setVisible(false);
    const length = (PIT[1] - PIT[0]) / 2;
    g.fillStyle(0x473429, 1).fillRoundedRect(-10, 2, length + 10, 18, 4);
    for (let plank = 0; plank < length; plank += 16) {
      const tint = plank % 48 === 0 ? 0xe7b474 : 0xc48b56;
      g.fillStyle(tint, 1).fillRoundedRect(plank, 0, 15, 12, 2);
      g.lineStyle(2, 0x75492f, .58).lineBetween(plank + 3, 9, plank + 11, 7);
      g.fillStyle(0x62412e, 1).fillCircle(plank + 4, 4, 1.4).fillCircle(plank + 12, 4, 1.4);
    }
    const posts = [0, 48, 99, 151];
    for (let i = 1; i < posts.length; i++) {
      const left = posts[i - 1];
      const right = posts[i];
      g.lineStyle(5, 0x60432c, 1).lineBetween(left, -29, (left + right) / 2, -21).lineBetween((left + right) / 2, -21, right, -29);
      g.lineStyle(2, 0xf1c989, 1).lineBetween(left, -30, (left + right) / 2, -23).lineBetween((left + right) / 2, -23, right, -30);
    }
    for (const post of posts) {
      g.fillStyle(0x4c3529, 1).fillRoundedRect(post - 5, -36, 10, 51, 3);
      g.fillStyle(0xb88454, 1).fillRoundedRect(post - 3, -34, 5, 43, 2);
      g.fillStyle(0xf5c986, 1).fillRect(post - 5, -31, 10, 4).fillCircle(post, 8, 2);
    }
    return g;
  }

  drawWater(stage, ms) {
    const g = this.water.clear();
    if (!hasPit(stage) || stage.mode === 'cable') return;
    const [left, right] = PIT;
    for (let i = 0; i < 6; i++) {
      g.fillStyle([0x40c6cc, 0x2eb6bd, 0x249fae, 0x218b9e, 0x21798f, 0x206c85][i], .9)
        .fillRect(left, FLOOR + 25 + i * 12, right - left, 12);
    }
    for (let i = 0; i < 18; i++) {
      const y = FLOOR + 29 + (i * 17 % 53) + Math.sin(ms / 420 + i) * 1.8;
      const x = left + 4 + ((i * 73 + ms * (.022 + (i % 3) * .009)) % (right - left - 9));
      const end = Math.min(right - 2, x + 11 + i % 6 * 5);
      g.lineStyle(i % 3 ? 2 : 3, i % 3 ? 0xd8fff0 : 0x92eee3, .33 + (i % 4) * .10)
        .lineBetween(x, y, end, y + Math.sin(ms / 390 + i) * 1.8);
    }
  }

  drawClouds(ms, left) {
    this.backdrop.setX(left * .53);
    this.nearBackdrop?.setX(left * .18);
    const g = this.clouds.clear();
    for (let i = 0; i < 5; i++) {
      const x = left * .43 + ((i * 323 + ms * (.004 + i * .0007)) % 1650);
      const y = 72 + (i * 17 % 83);
      g.fillStyle(0xe8fbff, .17).fillEllipse(x, y, 113, 11)
        .fillEllipse(x - 26, y - 3, 54, 12).fillEllipse(x + 13, y - 5, 60, 16);
    }
  }

  drawBridge(world, motion, ms, smooth, self) {
    const g = this.dynamic;
    const [lever, latch] = BRIDGE_SWITCHES;
    const [x, y, , , , grounded] = motion.players[self];
    const player = { x, y };
    const locked = world.puzzle.done;
    const holding = motion.pad.some(Boolean);
    this.bridgeLift = motion.bridge ? 1 : Phaser.Math.Linear(this.bridgeLift, motion.meter / 100, smooth);
    const angle = .43 * (1 - this.bridgeLift);
    this.bridgeDeck[0].setRotation(angle);
    this.bridgeDeck[1].setRotation(-angle);
    BRIDGE_SWITCHES.forEach((position, i) => {
      const near = grounded && within(player, position, FLOOR, BRIDGE_REACH);
      const live = i === 0 ? holding : motion.bridge;
      const bright = near || live || locked;
      g.fillStyle(bright ? 0xffdb78 : 0xe6cb99, near ? .35 : .16).fillEllipse(position, FLOOR - 1, 96, 18);
      g.lineStyle(2, bright ? 0xffdd78 : 0xb9b287, near ? .95 : .65).strokeEllipse(position, FLOOR - 1, 95, 17);
      g.fillStyle(0x4e3428, 1).fillRoundedRect(position - 24, FLOOR - 28, 48, 28, 5);
      g.fillStyle(0x9b6542, 1).fillRoundedRect(position - 19, FLOOR - 25, 38, 19, 4);
      g.lineStyle(2, 0xe1ad67, .8).lineBetween(position - 15, FLOOR - 22, position + 15, FLOOR - 22);
      this.bridgeSigns[i].setText(locked ? (i === 0 ? 'Pijakan aman' : '✓ Terkunci') : i === 0 ? '① TAHAN TUAS' : '② PENGUNCI')
        .setColor(bright ? '#ffe5a1' : '#e6e9cb');
    });
    const handle = lever + (holding ? 19 : -19);
    g.lineStyle(10, 0x50342a, 1).lineBetween(lever, FLOOR - 18, handle, FLOOR - 59);
    g.lineStyle(5, 0xc88d53, 1).lineBetween(lever, FLOOR - 18, handle, FLOOR - 59);
    g.fillStyle(holding ? 0xfbe791 : 0xe6a965, 1).fillCircle(handle, FLOOR - 60, 9);
    g.lineStyle(3, 0x754a30, 1).strokeCircle(handle, FLOOR - 60, 9);
    g.fillStyle(0x544034, 1).fillCircle(latch, FLOOR - 43, 23);
    g.lineStyle(4, locked ? 0xc6f0a6 : 0xdba871, 1).strokeCircle(latch, FLOOR - 43, 19);
    for (let i = 0; i < 6; i++) {
      const turn = i * Math.PI / 3 + (locked ? .35 : 0);
      g.lineBetween(latch, FLOOR - 43, latch + Math.cos(turn) * 17, FLOOR - 43 + Math.sin(turn) * 17);
    }
    g.fillStyle(locked ? 0xc6f0a6 : 0xf1ca87, 1).fillCircle(latch, FLOOR - 43, 5);
    if (locked) {
      g.fillStyle(0xf4c76c, 1).fillRoundedRect((PIT[0] + PIT[1]) / 2 - 10, FLOOR - 4, 20, 14, 3);
      const age = (Date.now() - (world.notice?.at ?? 0)) / 1000;
      if (world.notice?.kind === 'success' && age < 1.2) {
        for (let i = 0; i < 12; i++) {
          const ray = i * Math.PI / 6;
          g.fillStyle(i % 2 ? 0xffd57d : 0xc5f4af, Math.max(0, 1 - age / 1.2))
            .fillCircle(latch + Math.cos(ray) * (20 + age * 46), FLOOR - 46 + Math.sin(ray) * (20 + age * 46), 3 + i % 3);
        }
      }
    }
  }

  lantern(g, x, y, type, active, ms) {
    const c = PALETTE;
    g.fillStyle(0x2f4a41, .42).fillEllipse(x, y + 2, 42, 11);
    g.fillStyle(c.deep, 1).fillRoundedRect(x - 16, y - 13, 32, 14, 4);
    g.fillStyle(c.stone, 1).fillRoundedRect(x - 12, y - 24, 24, 15, 5);
    g.fillStyle(c.brown, 1).fillRoundedRect(x - 5, y - 52, 10, 36, 4);
    const t = active ? .26 + Math.sin(ms / 260) * .045 : .12;
    g.fillStyle(active ? c.gold : 0xa3cdb6, t).fillCircle(x, y - 46, 23 + Math.sin(ms / 350) * 2);
    g.fillStyle(active ? c.cream : 0xadd1b3, 1).fillRoundedRect(x - 12, y - 58, 24, 23, 5);
    g.lineStyle(3, c.brown, 1).strokeRoundedRect(x - 12, y - 58, 24, 23, 5);
    if (type === 'clue') {
      g.fillStyle(c.teal, 1).fillTriangle(x - 6, y - 45, x + 6, y - 45, x, y - 55);
    } else {
      g.fillStyle(c.brown, 1).fillCircle(x, y - 46, 3);
    }
  }

  switch(g, x, y, on, stage = 'wood') {
    const c = PALETTE;
    g.fillStyle(c.deep, .42).fillEllipse(x, y + 1, 43, 10);
    g.fillStyle(stage === 'wood' ? c.brown : c.stone, 1).fillRoundedRect(x - 17, y - 17, 34, 17, 4);
    g.lineStyle(5, c.deep, 1).lineBetween(x, y - 15, x + (on ? 12 : -12), y - 35);
    g.fillStyle(on ? 0xc6e7a3 : 0xefbb7b, 1).fillCircle(x + (on ? 12 : -12), y - 37, 7);
    g.lineStyle(2, c.brown, 1).strokeCircle(x + (on ? 12 : -12), y - 37, 7);
  }

  gate(g, x, y, open, special = false) {
    const c = PALETTE;
    g.fillStyle(0x29473d, .43).fillEllipse(x, y + 3, 103, 19);
    g.fillStyle(open ? 0x84b985 : c.deep, open ? .26 : .8).fillRoundedRect(x - 33, y - 110, 66, 111, 16);
    for (const sign of [-1, 1]) {
      const px = x + sign * 39;
      g.fillStyle(c.stone, 1).fillRoundedRect(px - 11, y - 102, 22, 102, 6);
      g.fillStyle(c.deep, .45).fillRect(px - 11, y - 22, 22, 4).fillRect(px - 11, y - 60, 22, 4);
      g.fillStyle(c.light, .58).fillRect(px - 7, y - 96, 3, 83);
      g.fillStyle(c.brown, 1).fillRoundedRect(px - 15, y - 8, 30, 10, 3);
    }
    g.fillStyle(c.stone, 1).fillRoundedRect(x - 57, y - 112, 114, 21, 8);
    g.fillStyle(c.cream, open ? 1 : .55).fillCircle(x, y - 105, special ? 15 : 9);
    g.lineStyle(2, c.brown, 1).strokeCircle(x, y - 105, special ? 15 : 9);
  }

  drawMechanism(stage, world, motion, ms, smooth, self) {
    const g = this.dynamic.clear();
    const c = PALETTE;
    const { mode, quizAt } = stage;
    const { puzzle } = world;
    const start = stageQuestionStart(world);
    const target = quizAt[world.q - start];
    for (let i = 0; i < quizAt.length; i++) {
      this.lantern(g, quizAt[i], FLOOR, 'quiz', i <= world.q - start, ms);
    }
    this.targetIcon.setVisible(target !== undefined && !world.quiz);
    if (target !== undefined) this.targetIcon.setText('✦').setPosition(target, FLOOR - 78 + Math.sin(ms / 170) * 4);
    if (stage.support) this.switch(g, CRANK, FLOOR, Boolean(world.quiz?.supported), 'stone');
    if (mode === 'bridge') this.drawBridge(world, motion, ms, smooth, self);
    if (mode === 'raft' || mode === 'cable') {
      this.raftX = this.raftX === undefined ? motion.raftX : Phaser.Math.Linear(this.raftX, motion.raftX, smooth);
      const x = this.raftX;
      if (mode === 'cable') {
        g.lineStyle(5, c.brown, .93).lineBetween(PIT[0] - 40, FLOOR - 123, PIT[1] + 55, FLOOR - 123);
        g.lineStyle(3, c.cream, .75).lineBetween(x - 67, FLOOR - 7, x, FLOOR - 120).lineBetween(x, FLOOR - 120, x + 67, FLOOR - 7);
        g.fillStyle(c.brown, 1).fillCircle(x, FLOOR - 120, 9);
      }
      g.fillStyle(c.brown, 1).fillRoundedRect(x - RAFT_HALF, FLOOR - 3, RAFT_HALF * 2, 18, 8);
      g.fillStyle(c.light, 1).fillRoundedRect(x - RAFT_HALF, FLOOR - 4, RAFT_HALF * 2, 8, 4);
      for (let i = 0; i < 9; i++) g.lineStyle(2, c.brown, .55).lineBetween(x - 85 + i * 21, FLOOR - 3, x - 85 + i * 21, FLOOR + 10);
      [-1, 1].forEach((sign, i) => this.switch(g, x + sign * RAFT_PAD, FLOOR, motion.pad[i]));
    }
    if (['lift', 'push', 'rope'].includes(mode)) {
      const x = puzzle.done ? 706 : 638 + motion.meter * .45;
      const y = puzzle.done ? FLOOR - 18 : FLOOR - motion.meter * .56;
      if (mode === 'push' && world.chapter === 2) {
        g.fillStyle(c.brown, 1).fillRoundedRect(x - 50, y - 74, 122, 67, 21);
        g.fillStyle(c.timber, 1).fillEllipse(x - 45, y - 41, 33, 59);
        g.lineStyle(3, c.brown, 1).strokeEllipse(x - 45, y - 41, 26, 45).strokeEllipse(x - 45, y - 41, 17, 28);
      } else if (mode === 'push') {
        g.fillStyle(c.deep, 1).fillRoundedRect(x - 48, y - 103, 108, 107, 15);
        g.fillStyle(c.stone, 1).fillRoundedRect(x - 44, y - 104, 97, 97, 14);
        g.lineStyle(3, 0xbac2a5, .75).lineBetween(x - 33, y - 81, x + 15, y - 81).lineBetween(x - 33, y - 67, x - 4, y - 67);
      } else {
        g.fillStyle(c.brown, 1).fillRoundedRect(x - 45, y - 104, 98, 107, 7);
        g.fillStyle(c.timber, 1).fillRoundedRect(x - 41, y - 101, 87, 92, 5);
        g.lineStyle(4, c.brown, .95).strokeRoundedRect(x - 36, y - 95, 77, 84, 4);
        g.lineBetween(x - 35, y - 93, x + 42, y - 13).lineBetween(x + 42, y - 93, x - 35, y - 13);
      }
      if (!puzzle.done) PADS.forEach((pad, i) => this.switch(g, pad, FLOOR, motion.pad[i]));
    }
    if (mode === 'clues') {
      this.lantern(g, ...CLUE_HIGH, 'clue', puzzle.found[(world.chapter + world.stage) % 2], ms);
      this.lantern(g, ...CLUE_LOW, 'clue', puzzle.found[1 - (world.chapter + world.stage) % 2], ms);
      this.switch(g, PATTERN, FLOOR, puzzle.done, 'stone');
      if (!puzzle.done) this.gate(g, 961, FLOOR, false);
    }
    if (mode === 'timing') {
      const first = (world.chapter + world.stage) % 2;
      TIMERS.forEach(([x, y], i) => this.switch(g, x, y, puzzle.done || Date.now() - puzzle.taps[i === 0 ? first : 1 - first] < 1350, 'stone'));
      if (!puzzle.done) this.gate(g, 943, FLOOR, false);
    }
    if (mode === 'climb') {
      const first = (world.chapter + world.stage) % 2;
      this.lantern(g, ...CLIMB, 'clue', puzzle.lanterns[first], ms);
      this.lantern(g, CLIMB[0] + 34, CLIMB[1], 'clue', puzzle.lanterns[1 - first], ms);
      if (!puzzle.done) this.gate(g, 951, FLOOR, false);
    }
    const canExit = puzzle.done && target === undefined;
    this.gate(g, EXIT, FLOOR, canExit, mode === 'gate');
    if (mode === 'gate') [EXIT - 48, EXIT + 24].forEach((pad, i) => this.switch(g, pad, FLOOR, motion.pad[i], 'stone'));
    if (canExit) {
      const y = FLOOR - 138 + Math.sin(ms / 215) * 4;
      g.fillStyle(c.gold, .32).fillCircle(EXIT, y, 16);
      g.fillStyle(c.gold, 1).fillTriangle(EXIT - 9, y, EXIT + 9, y, EXIT, y - 13).fillTriangle(EXIT - 9, y, EXIT + 9, y, EXIT, y + 13);
    }
  }

  update(ms, dt) {
    const data = this.read();
    if (!data?.world || !data.motion || data.world.phase !== 'play') return;
    const { world, motion, members, self } = data;
    const key = [world.run, world.chapter, world.stage].join(':');
    if (this.stageKey !== key) {
      this.stageKey = key;
      this.stageArt(world);
    }
    const smooth = 1 - Math.exp(-Math.min(dt, 60) / 49);
    const stage = stageOf(world);
    this.drawWater(stage, ms);
    this.drawMechanism(stage, world, motion, ms, smooth, self);
    for (let slot = 0; slot < 2; slot++) {
      const h = this.hero[slot];
      const [x, y, , face, pose, grounded] = motion.players[slot];
      const member = members[slot];
      if (!member) continue;
      const sprite = hasSpriteLook(member.avatar, member.role);
      h.image.setScale((sprite ? 1.01 : HERO_SCALE) / AVATAR_PIXELS).setOrigin(.5, sprite ? 440 / 448 : .905);
      const fx = Math.abs(x - h.image.x) > 185 ? 1 : smooth;
      h.image.setPosition(Phaser.Math.Linear(h.image.x, x, fx), Phaser.Math.Linear(h.image.y, y, fx));
      h.name.setText(CAST[member.role] + (slot === self ? ' ◇' : '')).setPosition(h.image.x, h.image.y - (sprite ? 184 : 146));
      const feedback = world.feedback && Date.now() - world.feedback.at < 1450 && world.feedback.role === slot ? world.feedback : null;
      const splashed = world.notice?.kind === 'danger' && world.notice.slot === slot && Date.now() - world.notice.at < 650;
      const expression = feedback ? (feedback.ok ? 'correct' : 'wrong')
        : splashed && pose === 'idle' ? 'surprise'
        : world.quiz?.role === slot && grounded && pose === 'idle' ? 'think'
          : world.notice?.kind === 'success' && Date.now() - world.notice.at < 1050 && pose === 'idle' ? 'celebrate' : pose;
      if (ms - this.lastArt >= 31) {
        if (h.expression !== expression) {
          h.expression = expression;
          h.expressionStarted = ms;
        }
        const artTime = sprite ? ms - h.expressionStarted : ms + slot * 300;
        drawAvatar(h.canvas.getContext(), member.avatar, member.role, expression, artTime, face);
        h.canvas.refresh();
      }
    }
    if (ms - this.lastArt >= 31) this.lastArt = ms;
    const local = this.hero[self].image;
    const camera = this.cameras.main;
    const zoom = Math.max(camera.height / 377, camera.width / WIDTH);
    const halfWidth = camera.width / (2 * zoom);
    const halfHeight = camera.height / (2 * zoom);
    const cameraSmooth = 1 - Math.exp(-Math.min(dt, 60) / 110);
    this.cameraX = Phaser.Math.Clamp(Phaser.Math.Linear(this.cameraX, local.x + halfWidth * .13, cameraSmooth), halfWidth, WIDTH - halfWidth);
    const targetY = Math.min(FLOOR + 78 - halfHeight, local.y + halfHeight * .2);
    this.cameraY = Phaser.Math.Clamp(Phaser.Math.Linear(this.cameraY, targetY, cameraSmooth), halfHeight, VIEW_H - halfHeight);
    camera.setZoom(zoom).centerOn(this.cameraX, this.cameraY);
    const g = this.foreground.clear();
    const left = this.cameraX - halfWidth;
    const right = this.cameraX + halfWidth;
    this.drawClouds(ms, left);
    for (let i = 0; i < 2; i++) {
      const hero = this.hero[i].image;
      if (hero.x < left || hero.x > right) {
        const side = hero.x < left ? -1 : 1;
        const x = side === -1 ? left + 19 : right - 19;
        const y = this.cameraY + halfHeight * .34;
        g.fillStyle(COLORS[i], .94).fillTriangle(x + side * 8, y, x - side * 7, y - 8, x - side * 7, y + 8);
      }
    }
  }
}

export function mountGame(parent, read) {
  const game = new Phaser.Game({
    type: Phaser.AUTO, parent, width: VIEW_W, height: VIEW_H,
    backgroundColor: '#1b4f47', antialias: true, banner: false,
    fps: { target: 60 }, audio: { noAudio: true },
    scale: { mode: Phaser.Scale.RESIZE },
    scene: [new AdventureScene(read)],
  });
  const resize = () => {
    const { clientWidth: width, clientHeight: height } = parent;
    if (!game.canvas || !width || !height || (width === game.scale.width && height === game.scale.height)) return;
    game.scale.resize(width, height);
  };
  const observer = new ResizeObserver(resize);
  observer.observe(parent);
  game.events.once(Phaser.Core.Events.READY, resize);
  game.events.once(Phaser.Core.Events.DESTROY, () => observer.disconnect());
  return game;
}
