import { MUSIC, TIMBRES } from './score.js';
export { MUSIC } from './score.js';
const FX = {
  right: [72, 76, 81], wrong: [61, 57, 54], clue: [67, 74], success: [64, 69, 73, 76],
  danger: [52, 43], travel: [59, 66, 71], final: [60, 64, 67, 72, 79], jump: [58, 65], explore: [64, 71],
};
const hz = note => 440 * 2 ** ((note - 69) / 12);

export class AudioEngine {
  constructor(settings) {
    this.settings = settings;
    this.key = 'aceh';
  }

  unlock() {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.music = this.ctx.createGain();
      this.effects = this.ctx.createGain();
      this.music.connect(this.ctx.destination);
      this.effects.connect(this.ctx.destination);
      this.apply(this.settings);
      this.change(this.key, true);
      this.timer = setInterval(() => this.schedule(), 75);
    }
    if (this.ctx.state !== 'running') this.ctx.resume().catch(() => {});
  }

  apply(settings) {
    this.settings = settings;
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    this.music.gain.setTargetAtTime(settings.mute ? 0 : settings.music * (this.focused ? .23 : .34), now, .12);
    this.effects.gain.setTargetAtTime(settings.mute ? 0 : settings.effects * .34, now, .05);
  }

  change(key, force = false) {
    if (!MUSIC[key] || (key === this.key && !force)) return;
    this.key = key;
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    if (this.track) {
      const old = this.track.gain;
      old.gain.cancelScheduledValues(now);
      old.gain.setTargetAtTime(0, now, .22);
      setTimeout(() => old.disconnect(), 1400);
    }
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(.001, now);
    gain.gain.setTargetAtTime(1, now + .08, .26);
    gain.connect(this.music);
    this.track = { gain, next: now + .09, i: 0 };
  }

  focus(focused) {
    if (this.focused === focused) return;
    this.focused = focused;
    this.apply(this.settings);
  }

  tone(output, type, frequency, t, length, level, attack = .012) {
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, t);
    gain.gain.setValueAtTime(.0001, t);
    gain.gain.exponentialRampToValueAtTime(level, t + Math.min(attack, length / 4));
    gain.gain.exponentialRampToValueAtTime(.0001, t + length);
    osc.connect(gain).connect(output);
    osc.start(t);
    osc.stop(t + length + .01);
  }

  schedule() {
    if (this.ctx.state !== 'running' || !this.track || document.hidden) return;
    const { step, root, tuning, lines } = MUSIC[this.key];
    const track = this.track;
    const now = this.ctx.currentTime;
    if (track.next < now - .2) track.next = now + .025;
    while (track.next < now + .2) {
      const i = track.i++;
      const t = Math.max(track.next, now);
      for (const { instrument, notes, octave, volume } of lines) {
        const degree = notes[i % notes.length];
        if (degree === null) continue;
        const position = tuning[degree % tuning.length] / 100 + 12 * (octave + Math.floor(degree / tuning.length));
        const frequency = hz(root + position);
        const accent = i % 8 === 0 ? 1 : i % 2 === 0 ? .84 : .72;
        const attack = instrument === 'reed' || instrument === 'flute' ? .038 : .007;
        for (const [ratio, level, duration] of TIMBRES[instrument]) {
          this.tone(track.gain, 'sine', frequency * ratio, t, duration, level * volume * accent, attack);
        }
      }
      track.next += step;
    }
  }

  cue(key) {
    if (!this.ctx || this.ctx.state !== 'running' || !FX[key]) return;
    const t = this.ctx.currentTime + .012;
    FX[key].forEach((note, i) => this.tone(this.effects, key === 'wrong' ? 'triangle' : 'sine', hz(note), t + i * .077, .205, .29));
  }
}
