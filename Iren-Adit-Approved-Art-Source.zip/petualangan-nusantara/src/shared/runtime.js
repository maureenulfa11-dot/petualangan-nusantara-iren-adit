export const APP_ORIGIN = 'https://game.nusantara.local';
export const PUBLIC_GAME_ORIGIN = 'https://petualangan-nusantara-iren-adit.maureenulfa11.workers.dev';
