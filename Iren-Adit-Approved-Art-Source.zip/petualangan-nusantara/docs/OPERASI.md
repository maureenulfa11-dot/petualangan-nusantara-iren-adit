# Operasi room

- Server menerima maksud gerak dan aksi melalui WebSocket. Posisi, lompatan, jarak dari tuas, waktu sakelar, giliran trivia, keping kompas, dan pembukaan bab dihitung oleh Durable Object.
- Kode undangan terdiri dari delapan karakter acak. Setiap kursi memiliki token acak 256 bit terpisah yang dikirim lewat subprotokol WebSocket, disimpan sebagai hash di server, dan tidak ikut dalam tautan undangan. Kursi penuh tetap dicadangkan untuk sambung ulang.
- Durable Object menyimpan checkpoint saat puzzle atau soal selesai dan saat pemain terputus. Saat sambung ulang, tombol yang sebelumnya ditahan dilepas. Room baru yang ditinggal dapat kedaluwarsa setelah sekitar 24 jam, sedangkan room dengan petualangan tersimpan setelah sekitar tujuh hari. Browser harus masih memiliki token untuk melanjutkan.
- Paket posisi ringkas dikirim saat pemain bergerak atau memegang aksi. Pesan ping memakai tanggapan otomatis WebSocket Hibernation. Penyimpanan tidak ditulis setiap frame. Endpoint masuk dan sambung ulang dibatasi menurut IP.
- Satu pemain yang terputus menjeda aksi bersama. Kegagalan jaringan dapat memicu percobaan ulang bertahap. Jika kapasitas layanan tercapai, menu menampilkan pesan coba lagi dan progres yang sudah disimpan tetap menjadi checkpoint.
- APK mengirim permintaan HTTPS dan WebSocket aman ke Worker yang sama. Origin WebView `https://game.nusantara.local` diizinkan secara eksplisit. Kunci kursi tetap diperlukan, dan undangan tetap memakai tautan web.
- Jembatan menyimpan status penguncian di checkpoint yang sudah ada. Pengangkatan sementara direset saat sambung ulang. Pemain yang sedang berada di atas sungai kembali ke tepi aman jika papan belum terkunci.

## Handoff pembaruan 9 November 2026

Cabang `repair/aceh-bridge-visuals` berisi perbaikan jembatan, antarmuka baru, PWA, dan proyek Android. Cadangan sebelum perubahan ada pada `backup/pre-bridge-repair-2026-11-09`. Git bundle berisi kedua cabang. Lihat [hasil uji](UJI.md) dan [inventaris musik](ASET.md).

Alamat `petualangan-nusantara-iren-adit.maureenulfa11.workers.dev` menyajikan versi produksi sebelumnya. Alamat `it.maureenulfa11.workers.dev` mengembalikan HTTP 404 dengan kode Cloudflare 1042 saat diperiksa. APK memakai alamat Worker game yang terverifikasi. Saat pengujian ini, koneksi GitHub terautentikasi sebagai `maureenulfa11-dot`, tetapi akses repositori privat proyek mengembalikan 404.

Tugas berikutnya adalah memulihkan akses hanya ke repositori game, mengunggah cabang perbaikan, dan menerbitkan pembaruan pada Worker yang sudah ada setelah verifikasi dan otorisasi. Uji satu room dari ikon PWA iPhone dan satu APK Android pada jaringan berbeda sebelum membagikan rilis.

## Pemakaian paket Free

Mulai dengan sejumlah kecil room undangan. Di dashboard **Workers & Pages**, buka Worker proyek ini dan periksa **Metrics** untuk request, error, dan CPU. Periksa juga **Durable Objects** untuk request, durasi, dan penulisan SQLite. Data pemakaian cloud baru tersedia setelah deploy ke akun pemilik.

Cloudflare menetapkan batas harian gratis untuk Workers dan Durable Objects. Periksa [Workers limits](https://developers.cloudflare.com/workers/platform/limits/) dan [Durable Objects pricing](https://developers.cloudflare.com/durable-objects/platform/pricing/) sebelum memperluas jumlah pemain. Batas yang tercapai dapat menolak operasi baru. Gunakan pengaturan Workers Free di akun saat menerbitkan dan tinjau grafik setelah uji awal.
