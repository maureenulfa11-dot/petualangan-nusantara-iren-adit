# Pasang Iren & Adit

## iPhone

1. Buka [Petualangan Nusantara: Iren & Adit](https://petualangan-nusantara-iren-adit.maureenulfa11.workers.dev) di Safari setelah pembaruan terbit.
2. Ketuk **Bagikan** → **Tambah ke Layar Utama**. Jika tersedia, aktifkan **Buka sebagai App Web**, lalu ketuk **Tambah**.
3. Buka ikon **Nusantara** di layar utama dan putar ponsel mendatar. Pilih **Buat Room** untuk mengundang satu teman.

Ini adalah aplikasi web yang dibuka dari layar utama. [Panduan Apple](https://support.apple.com/guide/iphone/iphea86e5236/ios)

## Android

1. Unduh `Iren-Adit-Android-Test.apk` dari paket uji.
2. Buka file tersebut di aplikasi **File** atau **Unduhan**. Jika Android meminta izin, pilih **Setelan** → **Izinkan dari sumber ini** untuk aplikasi yang membuka APK. Kembali dan pilih **Instal**.
3. Buka ikon **Petualangan Nusantara**. Aktifkan suara dengan mengetuk tombol menu. Mode room siap diuji setelah versi Worker dengan dukungan Android terbit.

APK ini memakai tanda tangan debug untuk pengujian di luar Google Play. Memasang build lain dengan tanda tangan berbeda dapat mengharuskan penghapusan build uji sebelumnya. Gunakan checksum SHA-256 yang menyertai APK untuk memeriksa berkas. [Panduan Android](https://support.google.com/android/answer/9457058)

## Room dari dua perangkat

Satu pemain membuat room, lalu membagikan kode atau tautan. Temannya membuka tautan dari browser atau memasukkan kode di aplikasi. Pilih **Saya Siap** di kedua perangkat. Untuk melanjutkan perjalanan lama, buka room dari browser atau aplikasi yang menyimpan sesi awal. Pemasangan yang memakai penyimpanan baru bisa membuat room baru.
