# Pengujian

## Cara mengulang

Siapkan Node.js 22 atau lebih baru. Dari folder proyek jalankan:

```sh
npm ci
npm run build
npm test
npx playwright install chromium
npm run test:browser
```

Pengujian browser standar memainkan seluruh Sumatra melalui dua sesi independen. Developer dapat menetapkan `NUSANTARA_FULL_BROWSER=1` untuk menjalankan alur sampai penutup Bali. `NUSANTARA_CHROMIUM` dapat menunjuk ke biner Chromium yang sudah tersedia. Wrangler memulai server uji lokal dengan penyimpanan sementara. Untuk menguji server yang sudah berjalan, tetapkan `NUSANTARA_URL` ke alamatnya.

## Hasil pembaruan 9 November 2026

| Pengujian yang dijalankan | Hasil |
| --- | --- |
| `npm run build` | Lulus pada Node 24.22.1. Bundle berisi sembilan panorama, gambar sampul, ikon, dan service worker. |
| `npm test` | 5 lulus. Termasuk 60 soal unik, semua jenis teka-teki, checkpoint SQLite setelah Worker dimulai ulang, penolakan origin asing, serta koneksi WebSocket dan preflight dari origin aplikasi Android. |
| `NUSANTARA_FULL_BROWSER=1 npm run test:browser` | 2 lulus. Dua proses Chromium 153 pada viewport 844 × 390 dan 915 × 412 menyelesaikan enam bab melalui antarmuka pemain dalam 219 detik. Alur memperoleh enam keping, menjawab 60 lentera, dan membuka semua adegan penutup Bali. |
| Jembatan Aceh dalam browser | Lulus. Papan turun memicu jatuh dan respawn. Tahan Aksi dengan input sentuh sebelum trivia menaikkan progres pada kedua layar. Papan diturunkan lagi saat dilepas. Putus di tengah lintasan mengembalikan pemain ke tepi aman. Pemain kedua mengunci dengan sentuhan dan keduanya berjalan di papan yang tetap terkunci. |
| Kustomisasi dan suara | Lulus untuk sinkronisasi pilihan avatar, audio Web Audio setelah interaksi, serta pergantian Aceh, Danau Toba, dan Minangkabau. Seluruh perjalanan menggunakan tema dari lokasi saat ini. |
| Potret dan PWA | Lulus untuk 390 × 844, perubahan ukuran kanvas saat rotasi, pesan putar ponsel, manifest standalone, ikon maskable, aset peluncuran Apple, service worker, dan menu luring. |
| `:app:assembleDebug` dan `apksigner verify` | Lulus di Linux dengan Java 21 dan SDK 36. APK bertanda tangan debug v2, ID `id.petualangannusantara.irenadit`, versi `1.1.0-test`, minimum SDK 24, dan target SDK 36. Klien web dalam APK cocok dengan hasil Vite. |
| `wrangler deploy --dry-run` | Lulus dengan 61 berkas aset, Worker game yang sama, Durable Object SQLite, dan rate limiter. |
| Pemeriksaan dependensi produksi dan paket | `npm audit --omit=dev` melaporkan nol kerentanan. Pemeriksaan paket tidak menemukan pola kunci privat atau token yang dicari. |

Lingkungan uji lokal memakai loopback untuk deteksi antarmuka jaringan Wrangler. Pengujian tetap menjalankan runtime Cloudflare dan dua proses browser yang terpisah. Tidak ada perangkat Android yang terdeteksi oleh ADB. Pemasangan di iPhone fisik, eksekusi APK pada Android fisik, dan room pada backend produksi yang diperbarui masih perlu diperiksa.

## Pengujian versi awal

Tanggal uji 8 November 2026. Runtime lokal menggunakan Node.js 24.22.1 dan Wrangler 4.158.0. Browser otomatis menggunakan Chromium 153 pada Linux.

| Pengujian | Hasil dan bukti |
| --- | --- |
| `npm run build` | Lulus. Vite menghasilkan paket klien dan service worker. |
| `npm test` | 4 lulus. Dua koneksi WebSocket independen, perebutan kursi kedua, penolakan token salah dan pemain ketiga, sinkronisasi avatar, gerak dan lompat, jeda ketika terputus, sambung ulang, dan pemulihan SQLite setelah proses Worker dimulai ulang. |
| Simulasi aturan di `tests/world.test.mjs` | Lulus seluruh 24 area dan 10 jenis mekanisme, memperoleh enam keping, menyelesaikan 60 soal unik, membagi giliran 30–30, dan mengocok ulang pada permainan baru. |
| Browser dengan dua sesi, 844 × 390 dan 915 × 412 | Lulus perjalanan enam pulau dalam 209,7 detik. Dua sesi menggunakan antarmuka pemain untuk menuntaskan 24 area, menjawab 60 lentera, mendapatkan keenam keping, melihat empat adegan penutup Bali, dan memulai permainan baru. Termasuk undangan, kustomisasi, lompat dan aksi angkat dengan input sentuh, jawaban salah dan percobaan ulang, pergantian musik Aceh–Toba–Minangkabau, dan sambung ulang setelah muat ulang. |
| Browser potret, 390 × 844 | Lulus pemeriksaan lebar, manifest, ikon, pemasangan service worker, dan pemuatan ulang menu saat luring. |
| `npx wrangler deploy --dry-run` | Lulus. Wrangler mengenali 44 berkas aset, binding Static Assets, Durable Object SQLite, dan rate limiter. |
| `npm audit --omit=dev` | Tidak ada kerentanan yang dilaporkan untuk paket produksi pada saat pengujian. Pemeriksaan paket klien juga tidak menemukan pola kredensial yang diuji atau bank jawaban. |

## Pemeriksaan setelah publikasi

1. Publikasikan Worker terpisah di akun Workers Free pemilik dan simpan salinan ke repositori GitHub privat.
2. Buka alamat HTTPS di Safari pada iPhone dan Chrome pada Android. Gunakan dua jaringan berbeda.
3. Buat room, buka tautan dari aplikasi pesan, lakukan lompatan dan tahan Aksi bersamaan. Kunci layar selama satu menit, sambungkan kembali, lalu periksa progres dan suara.
4. Tambahkan game ke layar utama. Periksa kontrol dalam mode lanskap, perpindahan aplikasi, pemulihan suara, serta ukuran tombol pada kedua ponsel.
5. Amati grafik pemakaian Worker dan Durable Object setelah beberapa sesi undangan.

Pengujian browser di atas memakai ukuran layar ponsel pada Chromium. Safari dan Chrome pada perangkat fisik, latensi antarjaringan, pemasangan PWA di layar utama, serta pemakaian produksi memerlukan pengujian pada alamat publik.
