# Inventaris aset

| Aset | Lokasi | Sumber atau lisensi |
| --- | --- | --- |
| Cuplikan papan cerita Sumatra | `public/art/referensi-sumatra.webp` | Dipotong dari gambar referensi yang disediakan pemilik proyek. Hak pada gambar tetap mengikuti kepemilikannya. |
| Ilustrasi sampul dan panorama | `public/art/iren-adit-cover.webp`, `public/art/*-painted.webp` | Ilustrasi baru yang dibuat untuk game dengan referensi visual dari pemilik. Sampul adalah satu pose ilustrasi. |
| Karakter, penampilan modular, pose, dan animasi | `src/client/avatar.js`, `src/shared/avatar-options.js` | Rig vektor berarsir untuk permainan, dibuat berdasarkan papan cerita. Atribut dapat diganti pada semua pose dan dirender pada resolusi 2×. Detailnya disederhanakan untuk ukuran karakter dalam permainan. |
| Latar vektor, peta ilustratif, dan ikon | `public/art/`, `scripts/draw-landscapes.py` | Ilustrasi proyek ini. Peta digunakan sebagai ilustrasi rute permainan. |
| Musik dan efek | `src/client/score.js`, `src/client/audio.js` | Komposisi dan efek asli yang disintesis oleh Web Audio. |
| Phaser 3.90.0 | `package.json`, `package-lock.json` | [MIT](licenses/phaser-MIT.md) |
| Capacitor Android 8.6.0 | `android/`, `package-lock.json` | [MIT](licenses/capacitor-MIT.txt) |
| AndroidX | `android/variables.gradle` dan dependensi Android | [Apache License 2.0](https://developer.android.com/jetpack/androidx) |
| Fraunces | `@fontsource-variable/fraunces` | [SIL Open Font License 1.1](licenses/fraunces-OFL.txt) |
| Plus Jakarta Sans | `@fontsource-variable/plus-jakarta-sans` | [SIL Open Font License 1.1](licenses/plus-jakarta-sans-OFL.txt) |

## Musik

| Lokasi | Identitas video referensi | Komposisi baru di game |
| --- | --- | --- |
| Aceh | Bungong Jeumpa, unggahan dengan lirik dan terjemahan. [Video](https://www.youtube.com/watch?v=96VSf0gyt5A) | **Angin di Serambi** memakai bunyi tiup berlapis dan ritme yang mengambil inspirasi dari serunee kalee dan rapa'i. |
| Danau Toba | Sinanggar Tulo, unggahan lagu Sumatra Utara. [Video](https://www.youtube.com/watch?v=Sn-sql3k4Bo) | **Riak di Kaki Kaldera** dengan suling, petikan, dan aksen perkusi berurutan. |
| Minangkabau | Ayam Den Lapeh, video musik Adim MF. [Video](https://www.youtube.com/watch?v=vmrJtvj-Geo) | **Gema Gonjong** dengan bunyi talempong sintetis dan jawaban suling yang terinspirasi saluang. |
| Jawa | Three short pieces from the Wayang Kulit. [Video](https://www.youtube.com/watch?v=BOhLsPZeozw) | **Gema Teras Candi** memakai metalofon, gong penanda frasa, dan kendang sintetis. |
| Kalimantan | Ampar Ampar Pisang, unggahan berjudul Aampar Ampar Pisang. [Video](https://www.youtube.com/watch?v=r9MwAD5-4VQ) | **Jalinan Arus Kayu** dengan dua lapis petikan yang terinspirasi sape. |
| Sulawesi | O Ina Ni Keke, unggahan dengan lirik dan terjemahan. [Video](https://www.youtube.com/watch?v=gOMbSd1R9uY) | **Dentang Lembah Pagi** memakai tiga lapis nada kayu yang terinspirasi kolintang. |
| Papua | Yamko Rambe Yamko, unggahan yang melabelinya sebagai lagu Papua. Atribusi asal masih diperdebatkan. [Video](https://www.youtube.com/watch?v=ovbrbW51Wmc) [Penelusuran asal](https://news.detik.com/berita/d-5070674/bpnb-papua-belum-ada-literatur-yamko-rambe-yamko-dari-bahasa-mana) | **Langkah di Punggung Awan** dengan pola drum dan hentakan terinspirasi tifa. |
| Bali | Kecak Sanghyang di Cultural Center Taiwan 2017. [Video](https://www.youtube.com/watch?v=pOFDAcboxtU) | **Senja Saling Menjawab** dengan dua pola pukulan instrumental yang saling mengisi, terinspirasi struktur ritmis Kecak. |
| Penutup | Adegan penutup game. | **Keping Terakhir** dengan petikan, suling, dan gong. |

Judul kedelapan video diperiksa melalui metadata YouTube. Izin penggunaan komersial untuk rekaman dan komposisi acuan belum terverifikasi. Semua rekaman acuan masih menunggu izin. Versi ini membundel komposisi baru dengan melodi, ritme, dan suara yang dibuat untuk game. [Jenis lisensi YouTube](https://support.google.com/youtube/answer/2797468)

Acuan instrumen dan praktik budaya. [Buku keragaman budaya Kemdikbud](https://static.buku.kemdikbud.go.id/content/media/pdf/PP_5_Keragaman_Budaya_Indonesia.pdf) [Gamelan](https://ich.unesco.org/en/RL/gamelan-01607) [Kolintang](https://ich.unesco.org/en/RL/cultural-practices-and-expressions-linked-to-balafon-and-kolintang-in-mali-burkina-faso-cote-d-ivoire-and-indonesia-02131) [Kecak](https://www.indonesia.travel/us/en/destination/bali-nusa-tenggara/bali/ubud---kecak-dance)

Musik otomatis berganti saat lokasi berubah, memudar saat perpindahan, dan tetap berputar saat trivia. Pemain dapat mengatur musik dan efek secara terpisah atau membisukan keduanya.

Bank soal menyertakan tautan sumber untuk kutipan, konteks meme, dan fakta publik. Kutipan Prabowo memakai frasa yang terdokumentasi di video pidato 2019. Sapaan yang terdengar pada bagian lain dijelaskan di dalam bank soal.
