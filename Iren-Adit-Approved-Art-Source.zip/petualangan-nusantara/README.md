# Petualangan Nusantara · Iren & Adit

Petualangan 2D berbahasa Indonesia untuk dua pemain. Temukan enam keping Kompas Nusantara dengan saling membantu dari Sumatra sampai Bali.

| Bab | Tempat dan tantangan |
| --- | --- |
| 1. Sumatra | Jembatan Aceh, rakit Danau Toba, dua jalur Minangkabau, dan pengangkatan balok |
| 2. Jawa | Batu besar, lorong candi, sakelar serempak, dan jembatan sawah |
| 3. Kalimantan | Rakit sungai, pohon tumbang, jembatan rumah panjang, dan gerbang rimba |
| 4. Sulawesi | Gondola katrol, ukiran Tongkonan, beban bertali, dan sakelar pesisir |
| 5. Papua | Pijakan pegunungan, petunjuk terpisah, karang Raja Ampat, dan gerbang batu |
| 6. Bali | Jalan tersembunyi, beban terakhir, jembatan kebun, dan gerbang kompas diikuti adegan penutup |

Ada 24 area dan 60 lentera trivia. Server mengocok satu bank bersama untuk setiap petualangan. Tiap bab mendapat tepat 10 soal, dan masing-masing pemain mendapat 30 giliran menjawab selama satu petualangan.

## Bermain setelah game diterbitkan

1. Buka alamat game di Safari, Chrome, atau aplikasi Android uji. Putar ponsel ke posisi mendatar.
2. Tekan **Buat Room**. Salin tautan undangan atau tekan **WhatsApp** untuk memilih teman yang ingin diundang.
3. Teman membuka tautan dan menekan **Gabung Room**. Kalian bisa mengatur penampilan sebelum menekan **Saya Siap**.
4. Pembuat room menekan **Mulai Game**. Gunakan tombol **Kiri**, **Kanan**, **Lari**, **Lompat**, dan **Aksi**. Ikuti petunjuk di bagian atas.
5. Jika koneksi salah satu pemain terputus, buka kembali room dari browser yang sama. Keping, jawaban, dan mekanisme yang selesai tersimpan di server. Simpan kode room jika perlu kembali lewat tautan.

Panduan [pemasangan di iPhone dan Android](docs/PASANG.md) mencakup cara menambahkan ikon ke layar utama dan memasang APK uji. Saat luring, menu yang sudah diunduh dapat terbuka. Room dan permainan bersama memerlukan internet.

## Menjalankan di komputer

Gunakan Node.js 22 atau lebih baru di Windows, macOS, atau Linux. Buka terminal di folder proyek dan jalankan:

```sh
npm ci
npm run dev
```

Buka alamat yang ditampilkan Wrangler, biasanya `http://localhost:8787`. Gunakan dua profil browser, satu jendela biasa dan satu jendela privat, atau dua perangkat. Gunakan alamat yang sama saat membuka undangan. Untuk ponsel di jaringan lokal yang sama, gunakan alamat IP komputer yang ditampilkan Wrangler. Pemasangan PWA di ponsel membutuhkan situs HTTPS.

## Menerbitkan pembaruan ke Cloudflare

1. Gunakan repositori [petualangan-nusantara-iren-adit](https://github.com/maureenulfa11-dot/petualangan-nusantara-iren-adit) dan Worker bernama `petualangan-nusantara-iren-adit` pada akun Workers Free pemilik.
2. Pulihkan cabang `repair/aceh-bridge-visuals` dari Git bundle jika diperlukan. Bandingkan dengan `main`, jalankan pengujian, lalu gabungkan setelah rilis disetujui. Integrasi Cloudflare menggunakan cabang `main`, build `npm run build`, deploy `npx wrangler deploy`, dan direktori akar `/`.
3. Verifikasi build produksi di Cloudflare. Gunakan [alamat game](https://petualangan-nusantara-iren-adit.maureenulfa11.workers.dev) untuk uji dua ponsel dengan jaringan berbeda. APK uji membutuhkan pembaruan Worker ini agar asal aplikasi Android dapat membuat room dan membuka WebSocket.

Panduan resmi [Cloudflare Workers Builds](https://developers.cloudflare.com/workers/ci-cd/builds/).

Developer dengan sesi Wrangler yang sudah terotorisasi bisa menjalankan `npm ci` dan `npm run deploy` dari repositori. Untuk memeriksa paket tanpa publikasi, jalankan `npm run build` dan `npx wrangler deploy --dry-run`.

## Membuat APK uji

Gunakan Node.js 22 atau lebih baru, Java 21, Android SDK Platform 36, dan Android Build Tools 35.0.0. Siapkan `JAVA_HOME` dan `ANDROID_HOME` untuk perangkat pengembangan. Jalankan `npm ci` dan `npm run android:apk` pada Linux atau macOS. Di Windows, jalankan `npm run android:sync`, lalu `gradlew.bat :app:assembleDebug` dari direktori `android`. Gradle Wrapper menghasilkan `android/app/build/outputs/apk/debug/app-debug.apk`. Jalankan `apksigner verify` dan buat checksum SHA-256 sebelum membagikannya.

## Memperbarui game

- **Soal** ada di `src/server/questions.js`. Pertahankan 60 ID unik dan empat pilihan tiap soal. Pertahankan ID dan urutan opsi saat room aktif agar checkpoint lama dapat dilanjutkan.
- **Bab dan teka-teki** ada di `src/shared/chapters.js` dan `src/server/world.js`. Setiap bab berisi 10 lentera. Data bab adalah konfigurasi bersama untuk server dan renderer.
- **Kostum** ada di `src/shared/avatar-options.js` dan `src/client/avatar.js`. Tambahkan pilihan di akhir daftar agar nomor kostum yang sudah tersimpan tetap menunjuk penampilan yang sama.
- **Latar** ada di `public/art/`. Berkas `*-painted.webp` adalah panorama baru. `scripts/draw-landscapes.py` menggambar lapisan vektor cadangan. Musik asli ada di `src/client/score.js` dan efek ada di `src/client/audio.js`.
- **Pengujian** dijelaskan di [docs/UJI.md](docs/UJI.md). Inventaris karya dan lisensi ada di [docs/ASET.md](docs/ASET.md).

Jika arsip menyertakan `backup/petualangan-nusantara.bundle`, berkas itu bisa diklon oleh Git untuk memulihkan riwayat proyek. Contoh perintah untuk developer:

```sh
git clone -b repair/aceh-bridge-visuals backup/petualangan-nusantara.bundle nusantara-restored
```
